import "./App.css";
import HabitContainer from "./components/HabitContainer";

function App() {
	return (
		<div className="App">
			<HabitContainer />
			<div className="backdrop">
				Please access this site in Desktop/Laptop for better experience.
			</div>
		</div>
	);
}

export default App;
